RUNEMOIRE — press kit
=====================

Runemoire is a pixel-art roguelike deckbuilder by Daniel Cortez / DC Solutions.
Six acts, six bosses with signature curses, three classes, 145 animated cards,
an endless mode and ten Grimoire Seals. Formerly known as Grimoire.

Contents
  logo/         logo, transparent logo, R icon, seal
  art/          key art (capsules and hero)
  screenshots/  in-game screenshots, English and Brazilian Portuguese (1920x1080)

Trailers: https://runemoire.com/#trailers
Contact: redes@runemoire.com

You may use these assets in coverage, reviews, streams and videos about the game.
